package org.example.listingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = ListingApplication.class)
public class SpringBootApplicationTest {
    @Test
    void contextLoads(){

    }

}
