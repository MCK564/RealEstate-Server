package org.example.listingservice.configurations;


public class MailConfig {
}
