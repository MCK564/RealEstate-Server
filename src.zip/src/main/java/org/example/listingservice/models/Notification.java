package org.example.listingservice.models;

public class Notification {
}
